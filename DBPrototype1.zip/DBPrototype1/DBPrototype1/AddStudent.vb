﻿Imports System.Text
Public Class AddStudent
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles EnterStudentButton.Click
        Dim utils As New Utils
        Dim FirstName As String = FirstNameTxtBox.Text ' sets the firstname to the text box 
        Dim LastName As String = FirstNameTxtBox.Text ' sets the lastname to the text box 
        Dim PCI As String = PCITxtBox.Text
        Dim Gender As String = GenderTxtBox.Text
        Dim Age As String = AgeTxtBox.Text
        Dim StudentiD As String = ""
        Dim number As Integer
        Dim Regex As New RegularExpressions.Regex("[a-z]")
        Randomize()

        number = Int(Rnd() * 80) + 1 ' creates a random number between 0 and 80

        If FirstName = "" Or LastName = "" Or PCI = "" Or Gender = "" Or Age = "" Then
            MsgBox("Message box empty") ' makes sure that the spaces arent left blank 

        ElseIf Not Regex.IsMatch(FirstName) Then
            MsgBox("incorrect name")

        ElseIf Not Regex.IsMatch(LastName) Then
            MsgBox("incorrect name")
        End If
        Dim studentinteger = utils.CreateStudentinteger
        StudentiD = FirstName.ElementAt(1) + LastName.ElementAt(1) + studentinteger ' creates the student id out of thefirst letter of the firstname and a random integer 
        Dim search = utils.QueryDatabase("Select StudentID from Login where StudentID = " & StudentiD & "'")
        If search.Count > 0 Then number += 1
        utils.AddToLoginTableForSudents(StudentiD, FirstName, LastName, Age, Gender, PCI)
    End Sub

End Class